To install deps, run "pip3 install -r requirements.txt"

To get info about running, run "python3 rsa_submission.py --help"

To decrypt my file, you can run "python3 rsa_submission.py decrypt -k encryption_keys.txt encrypted.txt"

My key_file is in the format:

p
q
n
e
d

