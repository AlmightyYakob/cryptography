To install deps, run "pip3 install -r requirements.txt"

To get info about running, run "python3 rsa_submission.py --help"

To decrypt my file, you can run "python3 decrypt -k encryption_keys.txt -o decrypted.txt encrypted.txt"
